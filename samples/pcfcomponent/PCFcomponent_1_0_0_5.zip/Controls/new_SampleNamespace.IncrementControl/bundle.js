/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./IncrementControl/index.ts":
/*!***********************************!*\
  !*** ./IncrementControl/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n/*\r\n    This file is part of the Microsoft PowerApps code samples.\r\n    Copyright (C) Microsoft Corporation.  All rights reserved.\r\n    This source code is intended only as a supplement to Microsoft Development Tools and/or\r\n    on-line documentation.  See these other materials for detailed information regarding\r\n    Microsoft code samples.\r\n\r\n    THIS CODE AND INFORMATION ARE PROVIDED \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER\r\n    EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF\r\n    MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.\r\n */\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.IncrementControl = void 0;\n\nvar IncrementControl =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function IncrementControl() {// no-op: method not leveraged by this example custom control\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  IncrementControl.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Creating the label for the control and setting the relevant values.\n    this.label = document.createElement(\"input\");\n    this.label.setAttribute(\"type\", \"label\");\n    this.label.addEventListener(\"blur\", this.onInputBlur.bind(this)); //Create a button to increment the value by 1.\n\n    this.button = document.createElement(\"button\"); // Get the localized string from localized string \n\n    this.button.innerHTML = context.resources.getString(\"IncrementControl_ButtonLabel\");\n    this.button.classList.add(\"SimpleIncrement_Button_Style\");\n    this._notifyOutputChanged = notifyOutputChanged; //this.button.addEventListener(\"click\", (event) => { this._value = this._value + 1; this._notifyOutputChanged();});\n\n    this.button.addEventListener(\"click\", this.onButtonClick.bind(this)); // Adding the label and button created to the container DIV.\n\n    this._container = document.createElement(\"div\");\n\n    this._container.appendChild(this.label);\n\n    this._container.appendChild(this.button);\n\n    container.appendChild(this._container);\n  };\n  /**\r\n   * Button Event handler for the button created as part of this control\r\n   * @param event\r\n   */\n\n\n  IncrementControl.prototype.onButtonClick = function (event) {\n    this._value = this._value + 1;\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * Input Blur Event handler for the input created as part of this control\r\n   * @param event\r\n   */\n\n\n  IncrementControl.prototype.onInputBlur = function (event) {\n    var inputNumber = Number(this.label.value);\n    this._value = isNaN(inputNumber) ? this.label.value : inputNumber;\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  IncrementControl.prototype.updateView = function (context) {\n    // This method would rerender the control with the updated values after we call NotifyOutputChanged\n    //set the value of the field control to the raw value from the configured field\n    this._value = context.parameters.value.raw;\n    this.label.value = this._value != null ? this._value.toString() : \"\";\n\n    if (context.parameters.value.error) {\n      this.label.classList.add(\"SimpleIncrement_Input_Error_Style\");\n    } else {\n      this.label.classList.remove(\"SimpleIncrement_Input_Error_Style\");\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\r\n   */\n\n\n  IncrementControl.prototype.getOutputs = function () {\n    // custom code goes here - remove the line below and return the correct output\n    var result = {\n      value: this._value\n    };\n    return result;\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  IncrementControl.prototype.destroy = function () {// no-op: method not leveraged by this example custom control\n  };\n\n  return IncrementControl;\n}();\n\nexports.IncrementControl = IncrementControl;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./IncrementControl/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./IncrementControl/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SampleNamespace.IncrementControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IncrementControl);
} else {
	var SampleNamespace = SampleNamespace || {};
	SampleNamespace.IncrementControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.IncrementControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}